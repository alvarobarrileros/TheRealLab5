﻿'' Author: Alvaro Barrileros-Ortiz
'' File : Lab 5
'' Date: 2020-07-18
'' Description : ( MAKE SURE TO COMPLETE THIS DUMMY )

Option Strict On

'' Allows for For File Stream
Imports System.IO



Public Class FrmTextEditor



    '' Code Exit Button from MenuStrip
    Private Sub mnubtnExit_Click(sender As Object, e As EventArgs) Handles mnubtnExit.Click
        Application.Exit()

    End Sub

    '' Code About Message box
    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click
        MsgBox("NETD 2202" & vbCrLf & "Lab #5" &
            vbCrLf & "A.Barrileros")
    End Sub

    Private Sub btnOpen_Click(sender As Object, e As EventArgs) Handles btnOpen.Click

        'Instantiates FileStream
        Dim fileRead As StreamReader


        If OpenFileDialog1.ShowDialog = DialogResult.OK Then
            Me.Text = "Text Editor " & OpenFileDialog1.FileName
            fileRead = New StreamReader(OpenFileDialog1.FileName)
            txtInput.Text = fileRead.ReadToEnd()
            fileRead.Close()

        End If

    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click

        'Clears the TextBox
        txtInput.Text = String.Empty

    End Sub


    Private Sub btnSaveAs_Click(sender As Object, e As EventArgs) Handles btnSaveAs.Click
        Dim saveStream As StreamWriter

        If SaveFileDialog1.ShowDialog = DialogResult.OK Then
            saveStream = New StreamWriter(SaveFileDialog1.FileName)
            saveStream.Write(txtInput.Text)
            saveStream.Close()
        End If
    End Sub

    'Set Cut Button
    Private Sub CutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles btnCut.Click
        Clipboard.SetText(txtInput.Text)
        txtInput.Text = ""
    End Sub

    'Set Paste Button
    Private Sub PasteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles btnPaste.Click
        txtInput.Text = Clipboard.GetText
    End Sub

    'Set Copy Button
    Private Sub btnCopy_Click(sender As Object, e As EventArgs) Handles btnCopy.Click
        Clipboard.SetText(txtInput.Text)
    End Sub
End Class